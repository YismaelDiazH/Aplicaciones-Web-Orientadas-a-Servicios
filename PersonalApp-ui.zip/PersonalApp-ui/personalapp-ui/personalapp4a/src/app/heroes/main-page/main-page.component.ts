import  {Component} from "@angular/core";

@Component({
    selector:'heroe-main-page',
    templateUrl: './main-page.component.html'

})
export class HeroesMainPageComponent {

}