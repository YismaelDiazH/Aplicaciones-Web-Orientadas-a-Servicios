import { NgModule } from "@angular/core";
import { HeroesMainPageComponent } from "./main-page/main-page.component";

@NgModule({
    declarations:[HeroesMainPageComponent],
    imports:[],//Solo se agregan otros modulos
    providers:[],//se agregan los servicios
    exports: [HeroesMainPageComponent],
})
export class HeroesModule{}